class Login {
  // конструктор класса, в котором сохраняем значения переданых атрибутов в класс
  constructor(form, fields) {
    this.form = form;
    this.fields = fields;
    this.validateonSubmit();
  }

  validateonSubmit() {
    let self = this; // сохраняем состояние this формы для дальнейшего использования

    // добавим прослушиватель событий "отправить" в форму
    this.form.addEventListener("submit", (e) => {
        // выключаем действие по умолчанию, т.е. переход на страницу action = /dashboard.html и отправку данных
        e.preventDefault();
        let error = 0;
        // продегаемся по массиву имен полей, который мы ранее переддали
        self.fields.forEach((field) => {
            const input = document.querySelector(`#${field}`);
            if (self.validateFields(input) == false) {
                // если не пройдена проверка то увеличиваем значение error на 1
                error++;
            }
        });
        // если пройдена вся проверка то переходим на страницу указаную в action = /dashboard.html
        if (error == 0) {
            // пишем в localStorage нужную информацию для определения, что пользователь залогинился
            localStorage.setItem("auth", 1);
            this.form.submit();
        }
    });
  }

  validateFields(field) {
    // remove any whitespace and check to see if the field is blank, if so return false
    // удалите все пробелы и проверьте, является ли поле пустым, если да, верните значение false
    if (field.value.trim() === "") {
        // установим статус поля в ошибку и передадим текст, вернем false что валидация не пройдена 
        // обрезали пробелым в начале и в конце строки и если строка равна нулевой строке '' то валидация не проходит 
        this.setStatus(
            field,
            `${field.previousElementSibling.innerText} не может быть пустым`,
            "error"
        );
        return false;
    } else {
        // если поле не пустое, проверяем поле равно типу passowrd или переходим к остальным полям
        if (field.type == "password") {
            const minLength = 5
            // сделаем проверку поля passowrd на длину  
            if (field.value.length < minLength) {
                // установим статус поля в ошибку и передадим текст, вернем false что валидация не пройдена 
                this.setStatus(
                    field,
                    `${field.previousElementSibling.innerText} не может быть короче ${minLength} символов`,
                    "error"
                );
                return false;
            } else {
                 // установим статус успешно пройдена валидация поля и вернем true
                this.setStatus(field, null, "success");
                return true;
            }
        } else {
            // установим статус успешно пройдена валидация поля и вернем true
            this.setStatus(field, null, "success");
            return true;
        }
    }
  }

  setStatus(field, message, status) {
        // создайте переменную для хранения сообщения
        const errorMessage = field.parentElement.querySelector(".error-message");
        // в случае успеха удалите сообщения и классы ошибок
        if (status == "success") {
            if (errorMessage) {
                errorMessage.innerText = "";
            }
            field.classList.remove("input-error");
        }
        // если ошибка, добавьте сообщения и классы ошибок
        if (status == "error") {
            errorMessage.innerText = message;
            field.classList.add("input-error");
        }
  }

}


// Находим форму
const form = document.querySelector(".loginForm")
if (form) {
  // создаем массив созначениями валидируемых полей
  const fields = ['username', 'password']
  // создаем экземпляр класса Login и передаем в него параметры
  const validator = new Login(form, fields)
}